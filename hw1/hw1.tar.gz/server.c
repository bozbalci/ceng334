#include "phgame.h"

int
main(int argc, char **argv)
{
    server_regsighandlers();
    server_main();
    
    return 0;
}
